@extends('base')

@section('content')
    <h1>
        Irsyad Zulfikar 
    </h1>
@endsection